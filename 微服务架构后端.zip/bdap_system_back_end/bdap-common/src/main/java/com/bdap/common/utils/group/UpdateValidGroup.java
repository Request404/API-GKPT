package com.bdap.common.utils.group;

public interface UpdateValidGroup {
}
