package com.bdap.ott.model.service;

import org.json.JSONObject;

public interface OssService {

  String getOssToken();
}
