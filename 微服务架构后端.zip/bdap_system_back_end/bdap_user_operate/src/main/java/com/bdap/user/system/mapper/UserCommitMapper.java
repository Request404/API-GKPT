package com.bdap.user.system.mapper;

import com.bdap.user.system.entity.UserCommit;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author GuoKeGD
 * @since 2020-12-01
 */
public interface UserCommitMapper extends BaseMapper<UserCommit> {

}
