package com.bdap.user.security.service;


import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserVerifyService extends UserDetailsService {
}
